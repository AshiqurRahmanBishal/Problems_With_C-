#include<iostream>
using namespace std;
int main(){
    float m,h, bmi;
    cout<<"the mass";
    cin>>m;
    bmi=(m/(h*h));
    cout<<"BMI is:"<<bmi;
    return 0;


    }
