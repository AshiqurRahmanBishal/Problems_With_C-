#include<iostream>
using namespace std;
int main(){
int a;
cout<<"an integer:";
cin>>a;
(a%2==0)?cout<<a<<"even.":cout<<a<<"odd";

return 0;
}
