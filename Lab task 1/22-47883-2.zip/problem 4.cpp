#include<iostream>
using namespace std;
int main (){
    int x,y;
    cout<<"first integer:";
    cin>>x;
    cout<<"second integer:";
    cin>>y;
    if(x%y==0){
            cout<<"first integer is multiple of second integer";}
    else{
        cout<<"first integer is not multiply of second integer";
    }

return 0;
}
